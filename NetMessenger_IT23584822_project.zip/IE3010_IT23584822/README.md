# NetMessenger — IE3010 Network Programming Assignment 2026

**Student registration number:** `IT23584822`

## Personalised values (derived from IT23584822)

| Item | Formula | Value |
|---|---|---|
| Numeric part (8 digits) | digits of the reg. number | `23584822` |
| Last four digits | last 4 of numeric part | `4822` |
| Listening port | 6000 + 4822 | **10822** |
| Node ID tag | digits 3–6 of `23584822` = **5**,**8**,**4**,**8** | **`NID:5848`** |
| Source files | `server_<last4>.c`, `client_<last4>.c` | `server_4822.c`, `client_4822.c` |
| Makefile | `Makefile_<last4>` | `Makefile_4822` |
| Log file | `netmsg_<regno>.log` | `netmsg_IT23584822.log` |
| Storage path | `./storage/<regno>/<sender>/<filename>` | `./storage/IT23584822/<sender>/<filename>` |
| Archive | `IE3010_<regno>.zip` | `IE3010_IT23584822.zip` |

## Build and run (gcc, Linux)

```bash
make -f Makefile_4822            # builds server_4822 and client_4822
./server_4822                    # terminal 1: listens on TCP 10822, logs to netmsg_IT23584822.log
./client_4822 alice              # terminal 2: registers as "alice" automatically
./client_4822 bob [server_ip]    # terminal 3: optional server IP (default 127.0.0.1)
make -f Makefile_4822 clean
```

Type raw protocol commands in a client: `LIST`, `BCAST hi all`, `PMSG bob hi`, `JOIN lobby`,
`RMSG lobby hello`, `ROOMS`, `LEAVE lobby`, `QUIT`.
For files type `SENDFILE <user|room> <path>` — the client sends
`SENDFILE <target> <basename> <size>\n` followed by exactly `<size>` raw bytes.
Received files are saved to `./received/<sender>_<filename>`.

Automated protocol tests (server must be running): `python3 tests/test_netmsg.py`

## Architecture in one paragraph
One process, one detached POSIX thread per client, a global `state_lock` guarding the user
table and room table, and a per-client `send_lock` so concurrent senders never interleave bytes
on one socket. Lock order is always `state_lock -> send_lock -> log_lock`. A per-client receive buffer
implements the line framing (partial lines, many lines per `recv`) and the exact-N-bytes
read used by `SENDFILE`.

## Decisions where the brief leaves a choice (assumptions)
* **Presence notices:** `MSG SYS USER_JOINED <name>` / `MSG SYS USER_LEFT <name>`.
* **Forwarded files:** to a user `MSG FILE <sender> <filename> <size>\n` + raw bytes;
  to a room `MSG RFILE <room> <sender> <filename> <size>\n` + raw bytes.
* **Extra error codes** (format `ERR <code> <REASON>` as required):
  001 USERNAME_TAKEN, 002 USER_NOT_FOUND, 003 ROOM_NOT_FOUND, 004 FILE_TOO_LARGE (limit 10 MB),
  005 BAD_FILENAME, 006 INVALID_USERNAME, 007 NOT_IN_ROOM, 009 UNKNOWN_COMMAND, 010 NOT_REGISTERED,
  011 ALREADY_REGISTERED, 012 BAD_SYNTAX, 013 STORAGE_ERROR, 014 SERVER_FULL, 015 TOO_MANY_ROOMS,
  016 LINE_TOO_LONG, 017 INVALID_ROOM_NAME, 018 SERVER_ERROR.
* Usernames/rooms: 1–32 chars of `A-Z a-z 0-9 _ -`; usernames compared case-insensitively.
* A `SENDFILE` target is looked up as a user first, then as a room.
* Posting to a room requires membership (`ERR 007 NOT_IN_ROOM`).
* Even when a `SENDFILE` is rejected, its `<filesize>` raw bytes are consumed so the stream stays in sync.
* Empty rooms are deleted automatically.

## Repository layout
`server_4822.c`, `client_4822.c`, `Makefile_4822`, `README.md`, `tests/`, `docs/` (design diary, prompt log, reflection, report).
