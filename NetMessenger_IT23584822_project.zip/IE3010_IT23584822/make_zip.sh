#!/usr/bin/env bash
# Run from the project root AFTER you have added YOUR report (docs/Implementation_Report_IT23584822.docx) and a log excerpt.
set -e
head -n 60 netmsg_IT23584822.log > netmsg_IT23584822_excerpt.log   # sample excerpt from YOUR run
mkdir -p /tmp/IE3010_IT23584822_pkg && rm -rf /tmp/IE3010_IT23584822_pkg/*
cp server_4822.c client_4822.c Makefile_4822 /tmp/IE3010_IT23584822_pkg/
cp netmsg_IT23584822_excerpt.log /tmp/IE3010_IT23584822_pkg/netmsg_IT23584822.log
cp docs/Implementation_Report_IT23584822.docx /tmp/IE3010_IT23584822_pkg/
(cd /tmp/IE3010_IT23584822_pkg && zip -r "$OLDPWD/IE3010_IT23584822.zip" .)
echo "Created IE3010_IT23584822.zip"
