#!/usr/bin/env python3
"""
Automated protocol tests for NetMessenger (IT23584822, port 10822, NID:5848).
Start the server first (./server_4822), then run:  python3 tests/test_netmsg.py
Prints PASS/FAIL per test -- use the output as evidence for your testing summary
(re-run it yourself; your report must show YOUR actual results).
"""
import hashlib, os, socket, sys, time

HOST, PORT, NID = "127.0.0.1", 6000 + 4822, "NID:5848"
results = []

class C:
    def __init__(self):
        self.s = socket.create_connection((HOST, PORT)); self.s.settimeout(3); self.buf = b""
    def send(self, t): self.s.sendall(t.encode() if isinstance(t, str) else t)
    def line(self):
        while b"\n" not in self.buf:
            d = self.s.recv(65536)
            if not d: raise EOFError
            self.buf += d
        l, self.buf = self.buf.split(b"\n", 1); return l.decode()
    def exact(self, n):
        while len(self.buf) < n:
            d = self.s.recv(65536)
            if not d: raise EOFError
            self.buf += d
        o, self.buf = self.buf[:n], self.buf[n:]; return o
    def cmd(self, t):
        self.send(t + "\n"); return self.line()
    def resp(self, t):
        """Send a command and return its OK/ERR reply, skipping queued MSG lines."""
        self.send(t + "\n")
        while True:
            l = self.line()
            if not l.startswith("MSG "): return l
    def close(self): self.s.close()

def reg(name):
    c = C(); r = c.cmd("REGISTER " + name); assert r == f"OK REGISTERED {name} {NID}", r; return c

def test(name):
    def deco(f):
        try: f(); results.append((name, True, ""))
        except Exception as e: results.append((name, False, repr(e)))
        return f
    return deco

U = str(int(time.time()) % 10000)
a, b, c3 = "alice" + U, "bob" + U, "carol" + U

@test("REGISTER ok + NID tag")
def _(): global A; A = reg(a)

@test("REGISTER duplicate -> ERR 001 USERNAME_TAKEN")
def _():
    x = C(); r = x.cmd("REGISTER " + a); assert r == f"ERR 001 USERNAME_TAKEN {NID}", r; x.close()

@test("Command before REGISTER rejected")
def _():
    x = C(); r = x.cmd("LIST"); assert r.startswith("ERR 010 NOT_REGISTERED") and r.endswith(NID), r; x.close()

@test("Join notification + LIST")
def _():
    global B; B = reg(b)
    assert A.line() == f"MSG SYS USER_JOINED {b}"
    r = B.cmd("LIST"); assert r.startswith("OK USERS") and a in r and b in r and r.endswith(NID), r
    A.s.settimeout(3)

@test("BCAST: others receive MSG BCAST, sender gets OK SENT")
def _():
    r = B.cmd("BCAST hello all"); assert r == f"OK SENT {NID}", r
    assert A.line() == f"MSG BCAST {b} hello all"

@test("PMSG delivered only to target")
def _():
    global C3; C3 = reg(c3); A.line(); B.line()
    assert A.cmd(f"PMSG {b} secret hi") == f"OK SENT {NID}"
    assert B.line() == f"MSG PRIV {a} secret hi"
    C3.s.settimeout(0.5)
    try: C3.line(); raise AssertionError("carol received private msg")
    except socket.timeout: pass
    C3.s.settimeout(3)

@test("PMSG unknown user -> ERR 002 USER_NOT_FOUND")
def _(): assert A.cmd("PMSG nobody_here hi") == f"ERR 002 USER_NOT_FOUND {NID}"

@test("JOIN creates room, ROOMS lists it")
def _():
    assert A.cmd("JOIN lobby") == f"OK JOINED lobby {NID}"
    assert B.cmd("JOIN lobby") == f"OK JOINED lobby {NID}"
    r = A.cmd("ROOMS"); assert "lobby" in r and r.endswith(NID), r

@test("RMSG only to room members")
def _():
    assert A.cmd("RMSG lobby team hello") == f"OK SENT {NID}"
    assert B.line() == f"MSG ROOM lobby {a} team hello"
    C3.s.settimeout(0.5)
    try: C3.line(); raise AssertionError("non-member received room msg")
    except socket.timeout: pass
    C3.s.settimeout(3)

@test("RMSG / LEAVE unknown room -> ERR 003 ROOM_NOT_FOUND")
def _():
    assert A.cmd("RMSG nosuchroom hi") == f"ERR 003 ROOM_NOT_FOUND {NID}"
    assert A.cmd("LEAVE nosuchroom") == f"ERR 003 ROOM_NOT_FOUND {NID}"

@test("LEAVE ok")
def _(): assert B.cmd("LEAVE lobby") == f"OK LEFT lobby {NID}"

@test("SENDFILE private: bytes identical, stored under personalised path")
def _():
    data = os.urandom(300_000); name = "t_" + U + ".bin"
    A.send(f"SENDFILE {b} {name} {len(data)}\n".encode())
    for i in range(0, len(data), 7000): A.send(data[i:i+7000]); time.sleep(0.0005)  # many recv() calls
    assert A.line() == f"OK FILE_RECEIVED {name} {NID}"
    hdr = B.line(); assert hdr == f"MSG FILE {a} {name} {len(data)}", hdr
    got = B.exact(len(data)); assert hashlib.sha256(got).digest() == hashlib.sha256(data).digest()
    p = f"storage/IT23584822/{a}/{name}"
    assert os.path.exists(p) and open(p, "rb").read() == data, "server copy missing/different"

@test("SENDFILE to room")
def _():
    A.cmd("JOIN filesroom"); B.cmd("JOIN filesroom")
    data = b"room file \x00\xff\n\r bytes"; 
    A.send(f"SENDFILE filesroom r.txt {len(data)}\n".encode() + data)
    assert A.line() == f"OK FILE_RECEIVED r.txt {NID}"
    hdr = B.line(); assert hdr == f"MSG RFILE filesroom {a} r.txt {len(data)}", hdr
    assert B.exact(len(data)) == data

@test("SENDFILE header+data in ONE segment, followed by command (framing)")
def _():
    data = b"abc\nLIST\nxyz"            # data contains newlines/commands: must NOT be parsed
    A.send(f"SENDFILE {b} f.txt {len(data)}\n".encode() + data + b"LIST\n")
    assert A.line() == f"OK FILE_RECEIVED f.txt {NID}"
    assert A.line().startswith("OK USERS")
    B.line(); B.exact(len(data))

@test("SENDFILE too large -> ERR 004, stream stays in sync")
def _():
    n = 11 * 1024 * 1024
    A.send(f"SENDFILE {b} big.bin {n}\n".encode())
    assert A.line() == f"ERR 004 FILE_TOO_LARGE {NID}"
    A.send(b"\0" * n)
    assert A.cmd("LIST").startswith("OK USERS")

@test("SENDFILE unknown target / bad filename")
def _():
    A.send(b"SENDFILE ghost x.bin 3\nabc"); assert A.line() == f"ERR 002 USER_NOT_FOUND {NID}"
    A.send(f"SENDFILE {b} ../evil 3\nabc".encode()); assert A.line() == f"ERR 005 BAD_FILENAME {NID}"
    assert A.cmd("LIST").startswith("OK USERS")

@test("Malformed / unknown / empty / over-long input does not crash")
def _():
    assert A.cmd("FOO bar") == f"ERR 009 UNKNOWN_COMMAND {NID}"
    assert A.cmd("BCAST") == f"ERR 012 BAD_SYNTAX {NID}"
    assert A.cmd("PMSG onlyname") == f"ERR 012 BAD_SYNTAX {NID}"
    A.send("\n")
    A.send("X" * 10000 + "\n"); assert A.line().startswith("ERR 016 LINE_TOO_LONG")
    assert A.cmd("LIST").startswith("OK USERS")

@test("Framing: partial lines and several lines in one send")
def _():
    A.send("LI"); time.sleep(0.2); A.send("ST\n"); assert A.line().startswith("OK USERS")
    A.send("LIST\nROOMS\nLIST\n")
    assert A.line().startswith("OK USERS") and A.line().startswith("OK ROOMS") and A.line().startswith("OK USERS")

@test("Ungraceful disconnect: peers notified, user removed")
def _():
    C3.s.close()                       # abrupt close, no QUIT
    seen = []
    for _ in range(6):
        try: seen.append(A.line())
        except socket.timeout: break
        if any("USER_LEFT " + c3 in s for s in seen): break
    assert any("USER_LEFT " + c3 in s for s in seen), seen
    assert c3 not in A.cmd("LIST")

@test("6+ simultaneous clients")
def _():
    cs = [reg(f"m{i}_{U}") for i in range(7)]
    r = cs[0].resp("LIST"); assert sum(f"m{i}_{U}" in r for i in range(7)) == 7, r
    for x in cs: x.resp("QUIT"); x.close()

@test("QUIT -> OK BYE and server closes")
def _():
    assert B.resp("QUIT") == f"OK BYE {NID}"
    B.s.settimeout(2)
    while True:                      # late MSG SYS notices may still be in flight; EOF must follow
        d = B.s.recv(4096)
        if d == b"": break

if __name__ == "__main__":
    ok = 0
    for n, p, e in results:
        print(("PASS  " if p else "FAIL  ") + n + ("" if p else "   <- " + e)); ok += p
    print(f"\n{ok}/{len(results)} tests passed"); sys.exit(0 if ok == len(results) else 1)
