# Structured reflection (300–500 words) — write this in YOUR OWN words
Marks (5) are for *specific, honest, analytical* answers. I have not written this for you, because it must
describe what you actually did and learned. Answer all four prompts below, each in a paragraph:

1. **Which AI tools did you use, and at which stages?**
   (e.g. Claude to generate a first draft of the server/client and templates; which parts you wrote or rewrote yourself.)
2. **What did the AI do well? Where did it get things wrong or mislead you?**
   (Be concrete. One real, verifiable example from this project: the first version had a race in `cleanup_client()` — it read
   `c->fd/c->ip` after releasing the slot, found by ThreadSanitizer. Also: the assignment PDF contains two different deadlines
   (30 Sept vs 7 Oct); a tool can't resolve that for you.)
3. **What did you change, add, or reject from the AI output, and why?**
   (Your own modifications — e.g. error codes, limits, naming, comments, anything you tested and altered.)
4. **What did you learn about your own understanding of network programming?**
   (TCP is a byte stream not messages; framing; exact-N-byte reads; thread safety; what you could/couldn't explain before reading the code.)
