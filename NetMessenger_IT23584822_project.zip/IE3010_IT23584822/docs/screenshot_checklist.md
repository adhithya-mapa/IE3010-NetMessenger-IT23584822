# Screenshot checklist for the Implementation Report (must be YOUR OWN runs — §8 forbids edited/fabricated shots)
Run `docs/demo.sh` helpers or do it manually. Use a large, readable terminal font; crop tightly.

- [ ] `make -f Makefile_4822` compiling with no warnings
- [ ] Server start-up line + `ss -tlnp | grep 10822`
- [ ] 3+ clients connected (use 5+ terminals for the concurrency requirement); `LIST` output showing NID:5848
- [ ] BCAST, PMSG, JOIN/RMSG/ROOMS/LEAVE with the receiving clients visible
- [ ] File transfer: sender, receiver message ("file saved"), `ls -lR storage/IT23584822` and `cmp`/`sha256sum` of original vs copy
- [ ] Error cases: `PMSG nobody hi`, `RMSG nosuch hi`, `FOO`, duplicate REGISTER, kill a client with `kill -9` and show the server log + USER_LEFT notice
- [ ] `head netmsg_IT23584822.log` (timestamps, correctly named file)
- [ ] `python3 tests/test_netmsg.py` showing PASS lines (your run)
- [ ] Code screenshots listed in the report template (section 5)
