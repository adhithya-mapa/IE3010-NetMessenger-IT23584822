#!/usr/bin/env bash
# Helper for taking screenshots. Usage: bash docs/demo.sh   (run from the project root, server already running)
echo "== listening socket =="; ss -tlnp 2>/dev/null | grep 10822 || netstat -tlnp 2>/dev/null | grep 10822
echo "== log (first lines) =="; head -n 15 netmsg_IT23584822.log
echo "== storage tree =="; ls -lR storage/IT23584822
