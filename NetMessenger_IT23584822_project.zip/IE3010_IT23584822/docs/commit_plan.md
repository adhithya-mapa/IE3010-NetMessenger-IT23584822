# Suggested commit sequence (you need >= 8 meaningful commits, spread over days)
Make these commits as you genuinely work through and understand each part — **do not back-date or batch them**;
the marker looks at real timestamps and the assignment treats misleading process evidence as an integrity issue.

1. `Add README with personalised values (port 10822, NID:5848) and Makefile_4822`
2. `server: TCP listener on port 10822, accept loop, per-client thread skeleton`
3. `server: line framing (read_line) and NID-tagged reply() helper`
4. `server: REGISTER/LIST with presence notifications`
5. `server: BCAST and PMSG`
6. `server: rooms — JOIN/LEAVE/ROOMS/RMSG`
7. `server: SENDFILE exact-N-byte read, storage under ./storage/IT23584822/<user>/`
8. `server: timestamped logging to netmsg_IT23584822.log, error handling, disconnect cleanup`
9. `client: select() loop, SENDFILE helper, file receive`
10. `tests: protocol test script; fix race in cleanup_client found by TSan`
11. `docs: design diary, prompt log, implementation report`
