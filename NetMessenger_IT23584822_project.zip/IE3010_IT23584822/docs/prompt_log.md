# AI prompt log — IE3010 NetMessenger (IT23584822)

Rules (assignment §3): record every *substantive* AI interaction — tool, prompt, and how you used or changed the output.
Entries below marked **[PRE-FILLED]** describe the one interaction I (the AI) can vouch for. Edit the "How I used it"
column honestly to match what you actually did. Add a row for every other AI use (debugging, report feedback, etc.).

| # | Date | Tool | Prompt (summary) | How the output was used / changed / rejected |
|---|------|------|------------------|----------------------------------------------|
| 1 | 2026-10-03 | Claude (Anthropic) | **[PRE-FILLED]** Uploaded the assignment PDF, gave registration number IT23584822, asked for the relevant documents and code. | Generated server_4822.c, client_4822.c, Makefile_4822, README, test script, report template, diary/log/reflection templates. Personalised values (port 10822, NID:5848, file names, log name, storage path) were computed by the AI — **I verified them by hand: ...** . The AI ran compile + automated tests and a ThreadSanitizer pass; it found and fixed a slot-reuse race in cleanup_client(). **I then read every function and ... (describe what you reviewed/changed/tested yourself).** |
| 2 | | | | |
| 3 | | | | |

## Things AI got wrong or I had to correct (feeds your reflection)
*e.g. ...*
