# Design diary — IE3010 NetMessenger (IT23584822)

> Keep this to 0.5–1 page. **Write each entry on the day it happens** — the viva will ask about it.
> The headings below are prompts; replace the italic text with your own words and dates.

## Entry 1 — <date>: Reading the spec and deriving personalised values
*What I computed (port 10822, NID:5848, files, log, storage) and how I double-checked it.*

## Entry 2 — <date>: Choosing the concurrency model
*Threads vs fork vs select/poll. Why I chose thread-per-client (simple per-client blocking state, shared
user/room tables under a mutex, 5+ clients is trivial). What I'd change for 10,000 clients (epoll).*

## Entry 3 — <date>: Framing and SENDFILE
*How I handled partial lines, multiple lines per recv(), and reading exactly <filesize> bytes.
The bug/obstacle I hit and how I found it.*

## Entry 4 — <date>: Rooms, errors and disconnects
*Design of the room table, what happens on ungraceful disconnect, the error codes I added.*

## Entry 5 — <date>: Testing
*What I tested, what failed, what I fixed.*

## Obstacles & lessons
*e.g. a race condition I found when a client slot was reused during cleanup (found with -fsanitize=thread).*
